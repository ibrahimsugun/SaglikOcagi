package com.muaynetakip.Models;

public enum Yetki {
	YONETICI,
	DOKTOR,
	HASTA,
	KAYIT_PERSONELI
}
